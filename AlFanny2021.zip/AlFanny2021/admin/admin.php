<?php include 'inc/Mheader.php';?>
<style>
.center {
  display: block;
  margin-left: auto;
  margin-right: auto;
  width: 100%;
}
</style>



  
<div class="container-fluid text-center">    
  <div class="row content">
  <div class="col-sm-2 sidenav">

          
                <div class="well">
                <p><a href="#">الخطة</a></p>
                </div>
                <div class="well">
                <p><a href="./plan.php">أجمالي التطهيرات</a></p>
                </div>
                <div class="well">
                <p><a href="./clean.php">الكميات المنجزة لاعمال التطهيرات</a></p>
                </div>
                <div class="well">
                <p><a href="./dug.php">الحفريات</a></p>
                </div>
                <div class="well">
                <p><a href="toolbar.php?pro=8&cat=1">حفارة ذ.ق/ج1 مبطن</a></p>
                </div>
                <div class="well">
                <p><a href="toolbar.php?pro=9&cat=1">حفارة ذ.ق/ح2 مبطن</a></p>
                </div>
                <div class="well">
                <p><a href="toolbar.php?pro=17&cat=1">حفارة ذ.ق/ج1 ترابية </a></p>
                </div>
                <div class="well">
                <p><a href="toolbar.php?pro=16&cat=1">حفارة ذ.ق/ج2 ترابية </a></p>
                </div>
                <div class="well">
                <p><a href="toolbar.php?pro=10&cat=1">حفارة ذ.ط/ج1 مبطن</a></p>
                </div>
                <div class="well">
                <p><a href="toolbar.php?pro=11&cat=1">حفارة ذ.ط/ج2 مبطن</a></p>
                </div>
                <div class="well">
                <p><a href="toolbar.php?pro=15&cat=1">حفارة ذ.ط/ج1 ترابية</a></p>
                </div>
                <div class="well">
                <p><a href="toolbar.php?pro=14&cat=1">حفارة ذ.ط/ج2 ترابية</a></p>
                </div>
                <div class="well">
                <p><a href="toolbar.php?pro=12&cat=1">سلكية </a></p>
                </div>
                <div class="well">
                <p><a href="toolbar.php?pro=13&cat=1">برمائية </a></p>
                </div>
                <div class="well">
                <p><a href="toolbar.php?pro=18&cat=1">حفريات / حفارة ذ.ق</a></p>
                </div>
                <div class="well">
                <p><a href="toolbar.php?pro=19&cat=1">حفريات /حفارة ذ.ط</a></p>
                </div>
                
    </div>
    
    <div class="col-sm-8 text-left"> 
                <div class="well">
                <p><center><a href="price_all.php"> تحليل أسعار فقرات تنفيذ أعمال التطهيرات و الشمبلان و أعمال الحفريات و رفع الترسبات</a></center></p>
                </div>
               <img src="inc/img/mesan.jpg" alt="محافظة ميسان" width="800" height="600" class="center">
    </div>
    <div class="col-sm-2 sidenav">
      

                <div class="well">
                <p><a href="#">الميزانية</a></p>
                </div>
                <div class="well">
                <p><a href="./flood.php">الميزانية / أجمالي درء الفيضان</a></p>
                </div>
                <div class="well">
                <p><a href="toolbar.php?pro=1&cat=1">سداد الكفاخ</a></p>
                </div>
                <div class="well">
                <p><a href="toolbar.php?pro=2&cat=1">كسر أيسر الكسارة</a></p>
                </div>
                <div class="well">
                <p><a href="toolbar.php?pro=3&cat=1">سداد نهر الجهاد</a></p>
                </div>
                <div class="well">
                <p><a href="toolbar.php?pro=4&cat=1">الكتف الايمن لنهر بيت هارف </a></p>
                </div>
                <div class="well">
                <p><a href="toolbar.php?pro=5&cat=1">سداد شرق دجلة </a></p>
                </div>
                <div class="well">
                <p><a href="toolbar.php?pro=6&cat=1">مستلزمات مقر الدائرة </a></p>
                </div>
                <div class="well">
                <p><a href="toolbar.php?pro=7&cat=1">اعمال ازالة نبات زهرة النيل</a></p>
                </div>
                
      </div>
  </div>
</div>


<?php include 'inc/footer.php';?>