

<footer >
<footer class="page-footer font-small blue pt-2">

 
  <div class="footer-copyright text-center py-8">© 2020 Copyright:
    <a href="https://mdbootstrap.com/"> برمجة و تصميم م.ر.مبرمجين أيناس القامجي</a>
  </div>
  <!-- Copyright -->




  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  
</footer>

</body>
</html>
