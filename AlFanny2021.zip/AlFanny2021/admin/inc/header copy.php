<?php include_once 'inc/config.php' ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>ALFANY</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.1/css/all.css">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <link rel="stylesheet" type="text/css" href="inc/style.css" />
  <style>
  
    /* Remove the navbar's default margin-bottom and rounded borders */ 
    .navbar {
      margin-bottom: 0;
      border-radius: 0;
    }
    
    /* Add a gray background color and some padding to the footer */
    footer {
      background-color: #f2f2f2;
      padding: 25px;
      text-align:center;
    }
  </style>
      <nav class="navbar navbar-inverse">
  <div class="container-fluid">

           <div class="collapse navbar-collapse" id="myNavbar">
          
      
          </div>
  </div>
</nav>
</head>