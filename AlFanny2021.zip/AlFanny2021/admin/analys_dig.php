<?php include 'inc/header.php'?>

<style>
.table>thead>tr>th {
    text-align: center;
    vertical-align: bottom;
    border-bottom: 2px solid #ddd;

    
}
</style>


<div class="jumbotron">
  <div class="container text-center">
    <center><h2>الحفريات و رفع الترسبات</h2></center>
  </div>
</div>

<!-- <center>
<form action="uploads.php" method="post" enctype="multipart/form-data">
<input type="file" name="file" />
<button type="submit" name="btn-upload">تحميل</button>
</form>


<table width="100%" border="1">
    <tr>
    <td>اسم الملف</td>
    <td>نوع الملف</td>
    <td>حجم الملف(KB)</td>
    <td>عرض الملف</td>
    </tr>
    <?php
 $sql="SELECT * FROM tbl_uploads";
 $result_set = mysqli_query($conn,$sql);
 while($row=mysqli_fetch_array($result_set))
 {
  ?>
        <tr>
        <td><?php echo $row['file'] ?></td>
        <td><?php echo $row['type'] ?></td>
        <td><?php echo $row['size'] ?></td>
        <td><a href="uploads/<?php echo $row['file'] ?>" target="_blank"><span class="glyphicon glyphicon-eye-open" > </span></a></td>
        
        </tr>
        <?php
 }
 ?>
</table>
</center> -->

<table width="100%" border="1" 
style='border-collapse: collapse;border-color: silver'; class='dataframe table my_table' dir="rtl">

<thead text-item:center>

<tr >
  
<th>ت</th>
<th>التفاصيل </th>
<th>الوحدة</th>
<th>انتاجية الحفارة الواحدة/يوم م.ط</th>
<th>السعر</th>
<th>السعر بدون مستلزمات دينار</th>
<th> مبلغ المستلزمات دينار(20%)</th>
<th>مبلغ الحراسات دينار/كم.ط</th>
<th>مبلغ الاطعام دينار/كم.ط </th>
<th>مبلغ السيارات دينار/كم.ط </th>
<th>مبلغ الزيوت والشحوم دينار/كم.ط </th>
<th>مبلغ الصيانة والتصليح دينار/كم.ط </th>
<th>عمال دينار/كم.ط </th>
<th>اليات مؤجرة دينار/كم.ط </th>

<th>المجموع</th>

<th> انتاجية المجموعة الواحدة/كم.ط</th>


</thead>
<tbody>
<?php


$sel_query= "SELECT *,
        (SELECT `amount`*`price`) `mprice`,
        (SELECT SUM(`cost`) FROM `sulfa` WHERE `sulfa`.`pro` = `projects`.`id`) `pprice`,
        (SELECT (`amount`*`price`)-`pprice`) `rprice`,
        (SELECT (`price`*20)/100) `staf_price`,
        (SELECT (`food`+`maintain`+`gard`+`car`+`oil`+`worker`+`rent_car`)) `new`
        FROM `projects` WHERE `type`=4 ;";
    $result = mysqli_query($conn,$sel_query);

    while($row = mysqli_fetch_assoc($result)) { ?>

    
        <tr >
            <td align="center"><?php echo $row["id"]; ?></td>

            <td align="center"><?php echo $row["name"]; ?></td>
            <td align="center"><?php echo $row["unit"]; ?></td>
            <td align="center"><?php echo number_format ($row["amount"]); ?></td>
            <td align="center"><?php echo number_format($row["price"]); ?></td>
            <td align="center"><?php echo number_format($row["new"]); ?></td>
            <td align="center"><?php echo number_format($row["staf_price"]); ?></td>
            <td align="center"><?php echo number_format ($row["gard"]); ?></td>
            <td align="center"><?php echo number_format ($row["food"]); ?></td>
            <td align="center"><?php echo number_format ($row["car"]); ?></td>
            <td align="center"><?php echo number_format ($row["oil"]); ?></td>
            <td align="center"><?php echo number_format ($row["maintain"]); ?></td>
            <td align="center"><?php echo number_format ($row["worker"]); ?></td>
            <td align="center"><?php echo number_format ($row["rent_car"]); ?></td>
            <td align="center"><?php echo number_format ($row["new"]); ?></td>
            <td align="center"><?php echo $row["producer"]; ?></td>
            
            
            
            
            
            
        </tr>
        <?php
    }

mysqli_close($conn); ?>
</tbody>
</table>
<script src="http://code.jquery.com/jquery-1.9.1.js"></script>
<script>
    $(function() {
        $(abc).each(function(){
            var txt = $(this).text();
            if( !isNaN(txt) && parseInt(txt) < 0 )
                $(this).parent().css('background-color', '#FF3333');
        });
    });
</script>
<?php include 'inc/footer.php'; ?>
