<?php include 'inc/Mheader.php';?>
<style>
.center {
  display: block;
  margin-left: auto;
  margin-right: auto;
  width: 100%;
}
</style>


                </div>
                <div class="well">
     
                </div>
                <div class="well">
                </div>
                <div class="well">
     
                </div>
                <div class="well">
<div class="container-fluid text-center">    
  <div class="row content">
  <div class="col-sm-2 sidenav">

          
                <div class="well">
                <p><a href="analys_shimp.php">أعمال الشمبلان</a></p>
                </div>
                
                
    </div>
    
    <div class="col-sm-8 text-left"> 
                <div class="well">
                <p><center><a href="analys_all.php"> تحليل فقرات اسعار أعمال التطهيرات و الشمبلان و أعمال الحفريات</a></center></p>
                </div>
               
    </div>
    <div class="col-sm-2 sidenav">
      

                <div class="well">
                <p><a href="analys_dig.php">الحفريات ورفع الترسبات</a></p>
                </div>
                
                
      </div>
  </div>
</div>
<div class="well">
                
                </div>
                <div class="well">
     
                </div>
                <div class="well">
                
                </div>
                </div>
                <div class="well">
     
                </div>
                <div class="well">


<?php include 'inc/footer.php';?>